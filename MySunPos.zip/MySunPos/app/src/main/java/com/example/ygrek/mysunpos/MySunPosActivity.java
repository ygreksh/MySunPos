package com.example.ygrek.mysunpos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

public class MySunPosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_sun_pos);
        EditText editTextLatitude = (EditText) findViewById(R.id.editTextLatitude);
        EditText editTextLongitude = (EditText) findViewById(R.id.editTextLongitude);
        TextView textViewAzimuth = (TextView) findViewById(R.id.textViewAzimuth);
        TextView textViewAltitude = (TextView) findViewById(R.id.textViewAltitude);
        TextView textViewDate = (TextView) findViewById(R.id.textViewDate);

        editTextLatitude.setText("46.84");
        editTextLongitude.setText("29.63");

        textViewAzimuth.setText("empty");
        textViewAltitude.setText("empty");
        textViewDate.setText("no date");

        TextView textViewYear = (TextView) findViewById(R.id.textViewYear);
        TextView textViewMonth = (TextView) findViewById(R.id.textViewMonth);
        TextView textViewDay = (TextView) findViewById(R.id.textViewDay);
        TextView textViewHour = (TextView) findViewById(R.id.textViewHour);
        textViewYear.setText("Year: ");
        textViewMonth.setText("Month: ");
        textViewDay.setText("Day: ");
        textViewHour.setText("Hour: ");

    }
    public void onClickCalc(View view){
        EditText editTextLatitude = (EditText) findViewById(R.id.editTextLatitude);
        EditText editTextLongitude = (EditText) findViewById(R.id.editTextLongitude);
        TextView textViewAzimuth = (TextView) findViewById(R.id.textViewAzimuth);
        TextView textViewAltitude = (TextView) findViewById(R.id.textViewAltitude);
        TextView textViewDate = (TextView) findViewById(R.id.textViewDate);

        double lat = Double.parseDouble(editTextLatitude.getText().toString());
        double lng = Double.parseDouble(editTextLongitude.getText().toString());
        Date date = new Date();
        Calendar calendar = GregorianCalendar.getInstance();
        //calendar.setTimeZone((TimeZone.getTimeZone("+2")));
        //calendar.add(Calendar.HOUR,2);
        Astronomy.CalculateSunPosition(calendar,lat,lng);
        //textViewAzimuth.setText(Double.valueOf(lat).toString());
        //textViewAltitude.setText(Double.valueOf(lng).toString());
        textViewAzimuth.setText(Double.valueOf(Astronomy.azimuth*Astronomy.Rad2Deg).toString());
        textViewAltitude.setText(Double.valueOf(Astronomy.altitude*Astronomy.Rad2Deg).toString());
        //textViewDate.setText(date.toString());
        textViewDate.setText(calendar.getTime().toString());

        TextView textViewYear = (TextView) findViewById(R.id.textViewYear);
        TextView textViewMonth = (TextView) findViewById(R.id.textViewMonth);
        TextView textViewDay = (TextView) findViewById(R.id.textViewDay);
        TextView textViewHour = (TextView) findViewById(R.id.textViewHour);
        textViewYear.setText("Year: " + calendar.get(Calendar.YEAR));
        textViewMonth.setText("Month: " + calendar.get(Calendar.MONTH));
        textViewDay.setText("Day: " + calendar.get(Calendar.DAY_OF_MONTH));
        textViewHour.setText("Hour: " + calendar.get(Calendar.HOUR_OF_DAY));


    }
}
